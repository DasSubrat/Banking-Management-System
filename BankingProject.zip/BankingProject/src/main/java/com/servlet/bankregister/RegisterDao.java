package com.servlet.bankregister;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class RegisterDao 
{
	public int register(RegisterBean rb)
	{
		int n=0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","subrat","1234");
			
			PreparedStatement st = con.prepareStatement("insert into sastabank(USERNAME, PASSWORD, AMOUNT,ADDRESS,PHONE) values (?,?,?,?,?)");
			st.setString(1, rb.getUserName());
			st.setString(2, rb.getPassword());
			
			st.setInt(3, rb.getAmount());
			st.setString(4, rb.getAddress());
			st.setLong(5, rb.getPhone());
		n=st.executeUpdate();
			
		} 
		catch (SQLIntegrityConstraintViolationException e) {
			return -1;
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return n;
		
		
	}
	
	public int getacNo(RegisterBean rb)
	{
		int acno=0;
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","subrat","1234");
			
			PreparedStatement st = con.prepareStatement("select * from sastabank where USERNAME=? and PASSWORD=?");
			st.setString(1, rb.getUserName());
			st.setString(2, rb.getPassword());
			ResultSet rs = st.executeQuery();
			if(rs.next())
			{
				acno=rs.getInt(3);
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return acno;
	}
	
}
